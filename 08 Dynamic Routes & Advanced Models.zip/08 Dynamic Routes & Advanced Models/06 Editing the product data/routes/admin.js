const path = require('path');
const express = require('express');

const adminController = require('../controllers/admin');

const router = express.Router();

router.get('/add-product', adminController.getAddProduct);

router.get('/products', adminController.getProducts);

router.post('/add-product', adminController.postAddProduct);

// edit-product get request
router.get('/edit-product/:productId', adminController.getEditProduct);

// edit-product post request (No dynamic part - because data can be taken from request body in a POST request)
router.post('/edit-product', adminController.postEditProduct);

module.exports = router;

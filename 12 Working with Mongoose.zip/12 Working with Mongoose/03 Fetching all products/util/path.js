const path = require('12 Working with Mongoose/03-fetching-all-products/util/path');

module.exports = path.dirname(process.mainModule.filename);
const mysql = require('mysql2');

// createPool() will return pool of connections (We need to create connection for each query.
// By using pool we can get connection when executing a query)
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    database: 'node-complete',
    password: 'Sachi2018'
});

// When handling async code we can use callbacks or promises.
// When we have more nested callbacks, structure of the code will be a mess
// By using promise it will be clear
module.exports = pool.promise();
const path = require('path');

const express = require('express');
const bodyParser = require('body-parser');

const errorController = require('./controllers/error');
// db is a pool of connections
const db = require('./util/database');

const app = express();

app.set('view engine', 'ejs');
app.set('views', 'views');

const adminRoutes = require('./routes/admin');
const shopRoutes = require('./routes/shop');

// execute() or query() can be used to run query
db.execute('SELECT * FROM products')  // This will return a promise
    // when success
  .then(result => {
      // result is a array of 2 arrays.
      // First array contains rows(each row as a object with key value pairs)
      // Second array contains details about the fields
    console.log(result[0], result[1]);
  })
  // when an error
  .catch(err => {
    console.log(err);
  });

// If we use callbacks we need to write like this
// db.execute('SELECT * FROM products', cb)
// when we have more callbacks it will be a mess (by nesting)


app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.use('/admin', adminRoutes);
app.use(shopRoutes);

app.use(errorController.get404);

app.listen(3000);

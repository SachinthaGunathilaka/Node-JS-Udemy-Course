
// middleware
// If not log in redirect to login page
module.exports = (req, res, next) => {
    if (!req.session.isLoggedIn) {
        // next will not execute
        return res.redirect('/login');
    }
    next();
}
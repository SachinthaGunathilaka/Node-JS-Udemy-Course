const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient; // Mongodb client

// get callback func as a argument
const mongoConnect = callback => {
  MongoClient.connect(
      // In mongoDB cloud, when connecting it will show a link
      //               username password                         dbname(set db name as test)
    'mongodb+srv://root:Sachi2018@cluster0.tauxv.mongodb.net/test?retryWrites=true&w=majority'
  )
    .then(client => {
      console.log('Connected!');
      callback(client); // execute call back function with client
    })
    .catch(err => {
      console.log(err);
    });
};

// In this case we need to create contact(client) with database for every requests
// Therefore we save our db in a variable

module.exports = mongoConnect;

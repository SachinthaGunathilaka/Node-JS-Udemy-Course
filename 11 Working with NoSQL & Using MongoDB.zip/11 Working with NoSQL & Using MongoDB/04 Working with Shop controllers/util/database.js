const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient;

let _db; // to hold the database

const mongoConnect = callback => {
  MongoClient.connect(
                                                              // dbname (if the db does not exist it will create a new one)
      'mongodb+srv://root:Sachi2018@cluster0.tauxv.mongodb.net/shop?retryWrites=true&w=majority'
  )
    .then(client => {
      console.log('Connected!');
      // _db hold the test database
      _db = client.db();
      callback(); // callback with empty parameters
    })
    .catch(err => {
      console.log(err);
      throw err; // throwing an error
    });
};

// return db if connected
const getDb = () => {
  if (_db) {
    return _db;
  }
  throw 'No database found!';
};

exports.mongoConnect = mongoConnect;
exports.getDb = getDb;

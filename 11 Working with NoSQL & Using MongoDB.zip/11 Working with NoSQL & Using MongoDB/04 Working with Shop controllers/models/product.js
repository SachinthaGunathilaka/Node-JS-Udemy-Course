// import getDb method
const getDb = require('../util/database').getDb;

class Product {
  // Product constructor
  constructor(title, price, description, imageUrl) {
    this.title = title;
    this.price = price;
    this.description = description;
    this.imageUrl = imageUrl;
  }

  // In mongoDb => Database - Collection - Document
  save() {

    // Id will be auto generated when add document (as _id)
    const db = getDb();
                  // collection name (If the collection does not exist it will create)
    return db.collection('products').insertOne(this) // insert one document and return the promise
        // insertOne takes object({key1: value1, key2:value2, . . .}) as the argument
      .then(result => {
        console.log(result);
      })
      .catch(err => {
        console.log(err);
      });
  }

  static fetchAll() {
    const db = getDb();
    // find() does not return a promise(It will return a cursor to go through the documents)
    // toArray() will return array of documents
    return db.collection('products').find().toArray()
      .then(products => {
        console.log(products);
        return products; // return promise (Inside a async func, if we return something it will return as a promise)
                         // Previously(when store data in a file) we use callbacks
      })
      .catch(err => {
        console.log(err);
      });
  }
}

module.exports = Product;

const path = require('path');

const express = require('express');
const bodyParser = require('body-parser');

const errorController = require('./controllers/error');
const sequelize = require('./util/database');
const Product = require('./models/product');
const User = require('./models/user');

const app = express();

app.set('view engine', 'ejs');
app.set('views', 'views');

const adminRoutes = require('./routes/admin');
const shopRoutes = require('./routes/shop');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.use('/admin', adminRoutes);
app.use(shopRoutes);

app.use(errorController.get404);

// Adding relations (This will auto create foreign keys)
// Users - Products (1 to N relation)
// 1 to N relation can be set as below. Only one method enough
// Second argument is optional
// This relations will execute with the sync ()
Product.belongsTo(User, { constraints: true, onDelete: 'CASCADE' });
User.hasMany(Product);



sequelize.sync({ force: true })
  .then(result => {
    // console.log(result);
    app.listen(3000);
  })
  .catch(err => {
    console.log(err);
  });


// Use below code to sync table with foreign keys (We cannot easily drop tables with FK)
// Only use onetime (If not database will be overwrite when server restarts)

// sequelize.query('SET FOREIGN_KEY_CHECKS = 0')
//     .then(() => {
//         sequelize.sync({
//             force: true
//         }).
//         then(() => {
//             sequelize.query('SET FOREIGN_KEY_CHECKS = 1')
//                 .then(result => {
//                     console.log('Database synchronised.');
//                     app.listen(3000);
//                 });
//         })
//     }).error(err => {
//     console.log(err);
// })

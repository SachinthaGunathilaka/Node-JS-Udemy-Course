const path = require('path');

const express = require('express');
const bodyParser = require('body-parser');

const errorController = require('./controllers/error');
const sequelize = require('./util/database');
const Product = require('./models/product');
const User = require('./models/user');

const app = express();

app.set('view engine', 'ejs');
app.set('views', 'views');

const adminRoutes = require('./routes/admin');
const shopRoutes = require('./routes/shop');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

// This will execute for all incoming requests
app.use((req, res, next) => {
  User.findById(1)
    .then(user => { // user is not just a js object. It is a sequelize model (save, destroy, . . . methods can be called)
      req.user = user; // Attache user model with id 1 to the request
      next(); // Call next middleware
    })
    .catch(err => console.log(err));
});

app.use('/admin', adminRoutes);
app.use(shopRoutes);

app.use(errorController.get404);

Product.belongsTo(User, { constraints: true, onDelete: 'CASCADE' });
User.hasMany(Product);


// This will only run when the server starts
sequelize.sync().then(result => {
    return User.findById(1); // find user by id and return a promise
  }).
    then(user => {
    if (!user) { // If user does not exists
      return User.create({ name: 'Max', email: 'test@test.com' }); // Create user and return promise (it contains the created user as the resolve parameter)
    }
    // If the user exists
    return Promise.resolve(user); // return promise with user as the resolve(promise contain resolve(then parameter) and reject(catch parameter))
    // We can only return user (Inside a then block if something is returned it will return as a promise (resolve parameter))

  })
  .then(user => { //
    // console.log(user);
    app.listen(3000);
  })
  .catch(err => {
    console.log(err);
  });

// Look the

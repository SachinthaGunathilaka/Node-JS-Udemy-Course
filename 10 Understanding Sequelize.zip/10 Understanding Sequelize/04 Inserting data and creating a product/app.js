const path = require('path');

const express = require('express');
const bodyParser = require('body-parser');

const errorController = require('./controllers/error');

// Import sequelize (user defined one)
const sequelize = require('./util/database');

const app = express();

app.set('view engine', 'ejs');
app.set('views', 'views');

const adminRoutes = require('./routes/admin');
const shopRoutes = require('./routes/shop');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.use('/admin', adminRoutes);
app.use(shopRoutes);

app.use(errorController.get404);

// sync() => Search all the model that defined by the object (sequelize) and creates table for them if they are not exists.
// Make sure to use same object(sequelize).  sequelize object is created in database.js file. That same object has
// imported to projuct.js and create model. In here also import same object.
sequelize.sync() // this returns a promise
  .then(result => {
    // console.log(result);
    app.listen(3000); // Only start the server if tables are created successfully
  })
  .catch(err => {
    console.log(err);
  });

// Import Sequelize module
const Sequelize = require('sequelize');

// Import configured Sequelize module (Our)
const sequelize = require('../util/database');

//     Model                      model name (usually lowercase of Model)
const Product = sequelize.define('product', {
  // Attributes of the model (Column names)
  id: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    allowNull: false,
    primaryKey: true
  },
  title: Sequelize.STRING,
  price: {
    type: Sequelize.DOUBLE,
    allowNull: false
  },
  imageUrl: {
    type: Sequelize.STRING,
    allowNull: false
  },
  description: {
    type: Sequelize.STRING,
    allowNull: false
  }
});

module.exports = Product;

const path = require('path');

const express = require('express');
const bodyParser = require('body-parser');

const errorController = require('./controllers/error');
const sequelize = require('./util/database');
const Product = require('./models/product');
const User = require('./models/user');
const Cart = require('./models/cart');
const CartItem = require('./models/cart-item');

const app = express();

app.set('view engine', 'ejs');
app.set('views', 'views');

const adminRoutes = require('./routes/admin');
const shopRoutes = require('./routes/shop');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.use((req, res, next) => {
  User.findByPk(1)
    .then(user => {
      req.user = user;
      next();
    })
    .catch(err => console.log(err));
});

app.use('/admin', adminRoutes);
app.use(shopRoutes);

app.use(errorController.get404);

// (Only one way is enough)
// User - Product -> 1 to N
// foreign key will be created automatically in Product table as userId(Product.belongsTo)
Product.belongsTo(User, { constraints: true, onDelete: 'CASCADE' });
User.hasMany(Product);

// New associations (Only one way is enough)
// User - Cart -> 1 to 1
// foreign key will be created in Cart (Cart.belongsTo)
User.hasOne(Cart);
Cart.belongsTo(User);

// New associations (Only one way is enough)
// Cart - Product -> M - N
// We need another table to connect M - N relations (that is the CartItem)
// CartItem itself contain some fields. Other than these fields foreign keys for Cart, Product table will be created.
// (foreign keys are cardId, productId)
Cart.belongsToMany(Product, { through: CartItem });
Product.belongsToMany(Cart, { through: CartItem });

sequelize
  // .sync({ force: true })
  .sync()
  .then(result => {
    return User.findByPk(1);
    // console.log(result);
  })
  .then(user => {
    if (!user) {
      return User.create({ name: 'Max', email: 'test@test.com' });
    }
    return user;
  })
    .then(user =>{
        // Create cart (With id = autoincrement , userId = id of the user)
        return user.createCart(); // This should be remove (This is just used for creating a cart for a user.)
    })
  .then(cart => {
    // console.log(cart);
    app.listen(3000);
  })
  .catch(err => {
    console.log(err);
  });

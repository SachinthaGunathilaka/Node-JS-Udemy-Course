const Sequelize = require('sequelize');

const sequelize = require('../util/database');

// Model for connecting product and user models
const CartItem = sequelize.define('cartItem', {
  id: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    allowNull: false,
    primaryKey: true
  },
  quantity: Sequelize.INTEGER

  // productId and userId will be added as foreign keys

});

module.exports = CartItem;

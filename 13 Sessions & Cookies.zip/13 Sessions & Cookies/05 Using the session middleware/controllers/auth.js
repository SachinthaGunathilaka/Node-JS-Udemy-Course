exports.getLogin = (req, res, next) => {
  //   const isLoggedIn = req
  //     .get('Cookie')
  //     .split(';')[1]
  //     .trim()
  //     .split('=')[1] === 'true';
  console.log(req.session.isLoggedIn);
  res.render('auth/login', {
    path: '/login',
    pageTitle: 'Login',
    isAuthenticated: false
  });
};

exports.postLogin = (req, res, next) => {
  // By using sessions can share some details across requests, not across users
  // Sessions also use cookies to identify user, but the information stored in the server. We cannot modify them
  // In here these data stored in the server memory (Best way is to store them in an online store)
  req.session.isLoggedIn = true;
  res.redirect('/');
};

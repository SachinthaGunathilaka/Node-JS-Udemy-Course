exports.getLogin = (req, res, next) => {
  res.render('auth/login', {
    path: '/login',
    pageTitle: 'Login',
    isAuthenticated: req.isLoggedIn
  });
};

// Post Login controller
exports.postLogin = (req, res, next) => {
    // this is not working. because isLoggedIn is only added to this request only.
    // Can we use global variable : No. It cannot be done in multiple user system
    req.isLoggedIn = true; // check whether the user is logged in or not
    res.redirect('/');
  };

const User = require('../models/user');

exports.getLogin = (req, res, next) => {
  res.render('auth/login', {
    path: '/login',
    pageTitle: 'Login',
    isAuthenticated: false
  });
};

exports.postLogin = (req, res, next) => {
  User.findById('5bab316ce0a7c75f783cb8a8')
    .then(user => {
      req.session.isLoggedIn = true;
        // user object added to database as a cookie (It only get attributes. We cannot call methods through it.)
        req.session.user = user;
      res.redirect('/');
    })
    .catch(err => console.log(err));
};

// Logout controller
exports.postLogout = (req, res, next) => {
    // inbuilt function to destroy session (It will remove from the database)
  req.session.destroy(err => {
    console.log(err);
    res.redirect('/');
  });
};

exports.getLogin = (req, res, next) => {
  // Get isLoggedIn cookie value
  // The problem in this is, we can change the cookie value manually from the browser
  const isLoggedIn = req.get('Cookie').split(';')[1].trim().split('=')[1];
  res.render('auth/login', {
    path: '/login',
    pageTitle: 'Login',
    isAuthenticated: isLoggedIn
  });
};

exports.postLogin = (req, res, next) => {
  // Setting cookies (cookies are saved on the browser)
  //                                         key     value
  res.setHeader('Set-Cookie', 'loggedIn=true');
  /*
    To see the cookies => browser -> inspect -> application -> cookies
    Cookies are sent with every requests
    To see requests => browser -> inspect -> network (-> headers => can see the headers(cookies also in there))

    res.setHeader('Set-Cookie', 'loggedIn=true; Expires=<date>; Max-Age=<time in second>');
                                                Can set attributes for expire (If we do not set, cookie will be expired when the browser closed)
  */
  res.redirect('/');
};
